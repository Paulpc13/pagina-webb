from django.apps import AppConfig


class FiestaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'fiesta'
